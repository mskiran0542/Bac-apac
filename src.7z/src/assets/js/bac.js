$(document).on("scroll", function(){
	if ($(document).scrollTop() > 70){
		$("header").addClass("fxg-header--shrunk");
	} else {
		$("header").removeClass("fxg-header--shrunk");
	}
});


$(document).ready(function(){
	//$("#openaccount").modal({show: false, backdrop: "static"});
	
	$(".help-icon").click(function(){
		if($(".help-icon").hasClass('close-icon')){
			$(this).find("img").attr("src","../../assets/images/icon-help.svg");
			$(".help-icon").attr("class","help-icon");			
		}else{			
			$(this).find("img").attr("src","../../assets/images/icon-close.svg");
			$(".help-icon").attr("class","help-icon close-icon");
		}		
		$(this).next(".help-text").slideToggle();
	});
});

