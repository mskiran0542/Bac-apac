import { Component, OnInit, NgModule } from '@angular/core';
import {MatButtonModule, MatInputModule, MatFormFieldModule, MatRadioModule} from '@angular/material';
import { FormControl, FormGroupDirective, NgForm, Validators, FormBuilder, FormGroup } from '@angular/forms';


@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
@NgModule({

 imports: [
    MatButtonModule,
    MatInputModule,
    MatFormFieldModule,
    MatRadioModule,
 ],
  exports: [
    MatButtonModule,
    MatInputModule,
    MatFormFieldModule,
    MatRadioModule,
  ],

})
export class CompanyComponent implements OnInit {
  selected = 'Guangdong Province';
  billingOption: string = "";
  myForm: FormGroup;
  validForm: boolean = false;
  buttonName: string = "SUBMIT";

  selectOption = [
    'Yes',
    'No (Please specify the reason)',
  ];

  constructor(private fb: FormBuilder) {
    this.myForm = fb.group(
      {
        'cNameCn': [null, Validators.required],
        'cNameEn': [null, Validators.required],
        'taxId': [null, Validators.required],
        'businessType': [null, Validators.required],
        'businessNature': [null, Validators.required],

        'companyAdr': [null, Validators.required],
        'entReason': [null, Validators.required],
        'billingAdr': [null, Validators.required],
        'postCode': [null, Validators.required],
      });
    }

  ngOnInit() {
  }
  onSubmit() {
    if (this.myForm.status == "VALID")
      this.validForm = true;
    alert(this.validForm);
  }

 
}
