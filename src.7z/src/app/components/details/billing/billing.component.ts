import { Component, OnInit, NgModule } from '@angular/core';
import {MatButtonModule, MatInputModule, MatFormFieldModule, MatRadioModule} from '@angular/material';
import {FormControl, FormGroupDirective, NgForm, Validators } from '@angular/forms';

@Component({
  selector: 'app-billing',
  templateUrl: './billing.component.html',
  styleUrls: ['./billing.component.css']
})
@NgModule({

 imports: [
    MatButtonModule,
    MatInputModule,
    MatFormFieldModule,
    MatRadioModule,
 ],
  exports: [
    MatButtonModule,
    MatInputModule,
    MatFormFieldModule,
    MatRadioModule,
  ],

})
export class BillingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
