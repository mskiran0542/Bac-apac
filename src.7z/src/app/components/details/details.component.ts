import { Component, OnInit, NgModule } from '@angular/core';
import { RouterModule, Routes, Router  } from '@angular/router';
import { MatButtonModule, MatInputModule, MatFormFieldModule, MatRadioModule } from '@angular/material';
import { FormControl, FormGroupDirective, NgForm, Validators, FormGroup, FormBuilder } from '@angular/forms';
// import { ContactComponent } from './contact/contact.component';
// import { CompanyComponent } from './company/company.component';


@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})

  @NgModule({
    // declarations: [ContactComponent, CompanyComponent],

    imports: [
      MatButtonModule,
      MatInputModule,
      MatFormFieldModule,
      MatRadioModule,
    ],
    exports: [
      MatButtonModule,
      MatInputModule,
      MatFormFieldModule,
      MatRadioModule,
    ],

  })


export class DetailsComponent implements OnInit {
  // myForm: FormGroup;
  // emailPattern: RegExp = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  // validForm: boolean = false;
  // buttonName: string = "SUBMIT";
  // billingOption: string = "";
  // selected = 'Guangdong Province';

  // selectOption = [
  //   'Yes',
  //   'No (Please specify the reason)',
  // ];
  showhide:boolean;

  constructor(private router: Router, private fb: FormBuilder){
    // this.myForm = fb.group(
    //   {
    //     'userName': [null, Validators.required],
    //     'mobileNumber1': [null, Validators.required],
    //     'mobileNumber2': [null],
    //     'email': [null, [Validators.required, Validators.pattern(this.emailPattern)]],
    //     'landLine': [null],
    //     'position': [null, Validators.required],


    //     'cNameCn': [null, Validators.required],
    //     'cNameEn': [null, Validators.required],
    //     'taxId': [null, Validators.required],
    //     'businessType': [null, Validators.required],
    //     'businessNature': [null, Validators.required],

    //     'companyAdr': [null, Validators.required],
    //     'entReason': [null, Validators.required],
    //     'billingAdr': [null, Validators.required],
    //     'postCode': [null, Validators.required],
    //   });
  }
  // onSubmit() {
  //   if (this.myForm.status == "VALID")
  //     this.validForm = true;
  //   alert(this.validForm);
  // }

  ngOnInit() {
    this.showhide=false;
  }
  gotoReviews(){
  this.router.navigate(['/review']);
  }
}
