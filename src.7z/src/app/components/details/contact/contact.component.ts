import { Component, OnInit, NgModule, EventEmitter, Output} from '@angular/core';
import {MatButtonModule, MatInputModule, MatFormFieldModule} from '@angular/material';
import {FormControl, FormGroupDirective, NgForm, Validators, FormGroup, FormBuilder } from '@angular/forms';



const modules = [
  MatButtonModule,
  MatInputModule,
];
@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
@NgModule({

 imports: [
    MatButtonModule,
    MatInputModule,
    MatFormFieldModule,
 ],
  exports: [
    MatButtonModule,
    MatInputModule,
    MatFormFieldModule,
  ],

})
export class ContactComponent implements OnInit {
  @Output() changeStatus: EventEmitter<boolean> = new EventEmitter<boolean>();
  myForm: FormGroup;
  emailPattern: RegExp = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  validForm: boolean = false;
  buttonName: string = "SUBMIT";
  billingOption: string = "";


  constructor(private fb: FormBuilder) { 

    this.myForm = fb.group(
      {
        'userName': [null, Validators.required],
        'mobileNumber1': [null, Validators.required],
        'mobileNumber2': [null],
        'email': [null, [Validators.required, Validators.pattern(this.emailPattern)]],
        'landLine': [null],
        'position': [null, Validators.required],
      });
    
  }
  onSubmit() {
    if (this.myForm.status == "VALID")
      this.validForm = true;
    alert(this.validForm);
  }

  ngOnInit() {
   
  }

}